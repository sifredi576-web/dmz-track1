module dmz_av_test_top(
 input wire clk_50m,run_n,mute_switch,pattern_switch,uart_rx,
 output wire SD_CS,SD_SCK,SD_MOSI,input wire SD_MISO,
 output wire uart_tx,output wire [7:0] leds,
 output wire HDMI_CLK_P,HDMI_D0_P,HDMI_D1_P,HDMI_D2_P);
wire pixel_clk,serial_clk,mem_clk,sdram_clk,locked;
dmz_p2_pll pll(.refclk(clk_50m),.reset(~run_n),.clk0_out(pixel_clk),.clk1_out(serial_clk),.mem_clk(mem_clk),.sdram_clk(sdram_clk),.locked(locked));
wire ar=~run_n|~locked;
reg [3:0] mr,pr;
always @(posedge mem_clk or posedge ar) if(ar) mr<=15;else mr<={mr[2:0],1'b0};
always @(posedge pixel_clk or posedge ar) if(ar) pr<=15;else pr<={pr[2:0],1'b0};
wire reset=mr[3],pixel_reset=pr[3];
wire ras_n,cas_n,we_n;wire [10:0] sa;wire [1:0] ba;wire [31:0] dq,dq_out;wire dq_oe;
assign dq=dq_oe?dq_out:32'bz;
EG_PHY_SDRAM_2M_32 memory(.clk(sdram_clk),.ras_n(ras_n),.cas_n(cas_n),.we_n(we_n),.addr(sa),.ba(ba),.dq(dq),.cs_n(1'b0),.cke(1'b1),.dm0(1'b0),.dm1(1'b0),.dm2(1'b0),.dm3(1'b0));
wire init_done,req_ready,rsp_valid,bist_done,bist_passed;
wire bvalid,bwrite,fvalid,fwrite;wire [20:0] baddr,faddr;wire [255:0] bwdata,fwdata,rdata;
wire [31:0] refreshes,errors,checked,first_expected,first_actual;wire [20:0] first_addr;wire [7:0] bist_status;
dmz_sdram_ctrl ctrl(.clk(mem_clk),.reset(reset),.req_valid(bist_done?fvalid:bvalid),.req_write(bist_done?fwrite:bwrite),.req_addr(bist_done?faddr:baddr),.req_wdata(bist_done?fwdata:bwdata),.req_ready(req_ready),.rsp_valid(rsp_valid),.rsp_rdata(rdata),.init_done(init_done),.refresh_count(refreshes),.ras_n(ras_n),.cas_n(cas_n),.we_n(we_n),.addr(sa),.ba(ba),.dq_out(dq_out),.dq_oe(dq_oe),.dq_in(dq));
dmz_sdram_bist bist(.clk(mem_clk),.reset(reset),.init_done(init_done),.req_valid(bvalid),.req_write(bwrite),.req_addr(baddr),.req_wdata(bwdata),.req_ready(req_ready&&!bist_done),.rsp_valid(rsp_valid&&!bist_done),.rsp_rdata(rdata),.done(bist_done),.passed(bist_passed),.errors(errors),.checked_words(checked),.first_bad_addr(first_addr),.first_expected(first_expected),.first_actual(first_actual),.status(bist_status));
wire [9:0] x,y;
reg frame_toggle;
always @(posedge pixel_clk) if(pixel_reset) frame_toggle<=0;else if(x==0&&y==480) frame_toggle<=~frame_toggle;
wire fifo_push,fifo_full,fifo_empty,fifo_reset;wire [31:0] fifo_in,fifo_out;wire [11:0] fifo_used;
wire display_valid,front_bank,fb_fault;wire [31:0] swaps,frames_written,dma_reads;
wire sd_ready,sd_done,sd_initialized,sd_byte_valid,sd_start;
wire [31:0] sd_lba,sd_sectors;wire [8:0] sd_index;wire [7:0] sd_byte,sd_error,sd_status;
dmz_sd_reader sd(.clk(mem_clk),.reset(reset),.read_start(sd_start),.read_lba(sd_lba),.ready(sd_ready),.initialized(sd_initialized),.read_done(sd_done),.byte_valid(sd_byte_valid),.byte_index(sd_index),.byte_data(sd_byte),.error(sd_error),.status(sd_status),.sectors_read(sd_sectors),.sd_cs(SD_CS),.sd_sck(SD_SCK),.sd_mosi(SD_MOSI),.sd_miso(SD_MISO));
wire load_valid,load_last,load_ready,load_ack,image_done;wire [17:0] load_addr;wire [255:0] load_data;
wire [7:0] image_error,image_status;wire [31:0] image_pixels;wire [63:0] image_name;
dmz_bmp_loader loader(.clk(mem_clk),.reset(reset),.enable(bist_passed),.sd_start(sd_start),.sd_lba(sd_lba),.sd_ready(sd_ready),.sd_done(sd_done),.sd_byte_valid(sd_byte_valid),.sd_byte_index(sd_index),.sd_byte_data(sd_byte),.sd_error(sd_error),.load_valid(load_valid),.load_addr(load_addr),.load_data(load_data),.load_last(load_last),.load_ready(load_ready),.load_ack(load_ack),.done(image_done),.error(image_error),.status(image_status),.pixels_loaded(image_pixels),.filename(image_name));
dmz_image_framebuffer fb(.load_valid(load_valid),.load_addr(load_addr),.load_data(load_data),.load_last(load_last),.load_ready(load_ready),.load_ack(load_ack),.clk(mem_clk),.reset(reset),.bist_done(bist_done),.bist_passed(bist_passed),.frame_toggle(frame_toggle),.req_valid(fvalid),.req_write(fwrite),.req_addr(faddr),.req_wdata(fwdata),.req_ready(req_ready&&bist_done),.rsp_valid(rsp_valid&&bist_done),.rsp_rdata(rdata),.fifo_used(fifo_used),.fifo_full(fifo_full),.fifo_push(fifo_push),.fifo_data(fifo_in),.fifo_reset(fifo_reset),.display_valid(display_valid),.front_bank(front_bank),.swaps(swaps),.frames_written(frames_written),.dma_reads(dma_reads),.fault(fb_fault));
reg [2:0] fr;
always @(posedge pixel_clk or posedge fifo_reset) if(fifo_reset) fr<=7;else fr<={fr[1:0],1'b0};
reg [1:0] dv,fail;
always @(posedge pixel_clk) if(pixel_reset) begin dv<=0;fail<=0;end else begin dv<={dv[0],display_valid};fail<={fail[0],bist_done&&!bist_passed};end
wire active=x<640&&y<480;
wire pop=active&&x[0]&&dv[1]&&!fr[2];
dmz_pixel_fifo fifo(.wclk(mem_clk),.wreset(fifo_reset),.wpush(fifo_push),.wdata(fifo_in),.full(fifo_full),.used(fifo_used),.rclk(pixel_clk),.rreset(fr[2]),.rpop(pop),.rdata(fifo_out),.empty(fifo_empty));
reg [31:0] underflow,uf_gray;
always @(posedge pixel_clk) begin
 if(pixel_reset) begin underflow<=0;uf_gray<=0;end
 else if(active&&dv[1]&&!fr[2]&&fifo_empty) begin underflow<=underflow+1'b1;uf_gray<=((underflow+1'b1)>>1)^(underflow+1'b1);end
end
(* ASYNC_REG="TRUE" *) reg [31:0] uf1,uf2;
always @(posedge mem_clk) if(reset) begin uf1<=0;uf2<=0;end else begin uf1<=uf_gray;uf2<=uf1;end
function automatic [31:0] fromgray(input [31:0] g);integer k;begin fromgray[31]=g[31];for(k=30;k>=0;k=k-1) fromgray[k]=fromgray[k+1]^g[k];end endfunction
wire [31:0] underflow_mem=fromgray(uf2);
wire [15:0] p565=x[0]?fifo_out[31:16]:fifo_out[15:0];
reg [23:0] rgb;
always @(posedge pixel_clk) begin
 if(pixel_reset) rgb<=0;
 else if(fail[1]) rgb<=24'hff0000;
 else if(!dv[1]) rgb<=image_error!=0?24'hff8000:24'h000040;
 else if(fifo_empty||fr[2]) rgb<=24'hff00ff;
 else rgb<={p565[15:11],p565[15:13],p565[10:5],p565[10:9],p565[4:0],p565[4:2]};
end
// Audio test: enabled after reset; SW1 high mutes, SW2 high selects continuous tone.
// SW2 low gives one second tone / one second silence for an audible control test.
reg [1:0] mute_sync,continuous_sync;
reg [24:0] audio_phase_clock;
reg beep_phase;
always @(posedge pixel_clk) begin
 if(pixel_reset) begin mute_sync<=0;continuous_sync<=0;audio_phase_clock<=0;beep_phase<=1;end
 else begin
  mute_sync<={mute_sync[0],mute_switch};continuous_sync<={continuous_sync[0],pattern_switch};
  if(audio_phase_clock==24999999) begin audio_phase_clock<=0;beep_phase<=~beep_phase;end
  else audio_phase_clock<=audio_phase_clock+1'b1;
 end
end
// Default: sound on. U=continuous, M=mute, B=beep, S=physical switches.
wire command_valid;wire [7:0] command_byte;
reg [1:0] audio_mode;
dmz_uart_rx command_rx(.clk(pixel_clk),.reset(pixel_reset),.rx(uart_rx),.valid(command_valid),.data(command_byte));
always @(posedge pixel_clk) begin
 if(pixel_reset) audio_mode<=2'd1;
 else if(command_valid) case(command_byte)
  "U","u":audio_mode<=1;
  "M","m":audio_mode<=2;
  "B","b":audio_mode<=3;
  "S","s":audio_mode<=0;
  default:begin end
 endcase
end
wire tone_muted=(audio_mode==2) || (audio_mode==3 && !beep_phase) ||
 (audio_mode==0 && (mute_sync[1] || (!continuous_sync[1] && !beep_phase)));
wire [31:0] dbg_samples,dbg_pcm_packets,dbg_nonzero_packets,dbg_acr_packets,dbg_pcm_pair;
wire [19:0] dbg_cts;

wire sample_ce;wire signed [15:0] sample;wire [15:0] aw[1:0];assign aw[0]=sample <<< 1;assign aw[1]=sample <<< 1;
dmz_tone tone(.clk(pixel_clk),.reset(pixel_reset),.mute(tone_muted),.sample_ce(sample_ce),.sample(sample));
wire [2:0] tmds;
hdmi #(.VIDEO_ID_CODE(1),.VIDEO_REFRESH_RATE(59.5238095238),.AUDIO_RATE(48000),.AUDIO_BIT_WIDTH(16),.VENDOR_NAME("DMZ     "),.PRODUCT_DESCRIPTION("DMZ Audio Test  ")) tx(.clk_pixel_x5(serial_clk),.clk_pixel(pixel_clk),.clk_audio(sample_ce),.reset(pixel_reset),.rgb(rgb),.audio_sample_word(aw),.tmds(tmds),.tmds_clock(HDMI_CLK_P),.dbg_samples(dbg_samples),.dbg_pcm_packets(dbg_pcm_packets),.dbg_nonzero_packets(dbg_nonzero_packets),.dbg_acr_packets(dbg_acr_packets),.dbg_cts(dbg_cts),.dbg_pcm_pair(dbg_pcm_pair),.cx(x),.cy(y),.frame_width(),.frame_height(),.screen_width(),.screen_height());
assign {HDMI_D2_P,HDMI_D1_P,HDMI_D0_P}=tmds;
reg [31:0] uptime;always @(posedge mem_clk) if(reset) uptime<=0;else uptime<=uptime+1'b1;
wire [31:0] words[15:0];
assign words[0]=32'h54535641; // "AVST"
assign words[1]={10'd0,audio_mode,continuous_sync[1],beep_phase,mute_sync[1],tone_muted,locked,fb_fault,(underflow_mem!=0),front_bank,display_valid,bist_passed,bist_done,init_done,8'd1};
assign words[2]=dbg_samples;assign words[3]=dbg_pcm_packets;assign words[4]=dbg_nonzero_packets;
assign words[5]=dbg_acr_packets;assign words[6]={12'd0,dbg_cts};assign words[7]={16'd6144,16'd48000};
assign words[8]=errors;assign words[9]=dv[1]?image_pixels:0;assign words[10]=underflow;
assign words[11]={sd_error,image_error,sd_status,image_status};assign words[12]=checked;
assign words[13]=dbg_pcm_pair;assign words[14]={7'd0,audio_phase_clock};
reg [31:0] checksum;integer n;always @* begin checksum=0;for(n=0;n<15;n=n+1) checksum=checksum^words[n];end
assign words[15]=checksum;
wire [511:0] status;genvar i;generate for(i=0;i<16;i=i+1) begin assign status[32*i+:32]=words[i];end endgenerate
dmz_status_uart #(.DIVISOR(217),.PERIOD(12500000)) telemetry(.clk(pixel_clk),.reset(pixel_reset),.status(status),.tx(uart_tx));
assign leds={fb_fault,(underflow_mem!=0),~tone_muted,display_valid,mute_sync[1],bist_passed,init_done,uptime[24]};
endmodule
