// File-byte stream to RGB565 bursts, independent of FAT/SD transport.
module dmz_bmp_decoder(input clk,reset,start,input [31:0] file_bytes,input [7:0] stream_error,
 input byte_valid,output wire byte_ready,input [7:0] byte_data,
 output wire load_valid,output reg [17:0] load_addr,output reg [255:0] load_data,
 output reg load_last,input load_ready,load_ack,
 output reg done,output reg [7:0] error,output wire [7:0] status,output reg [31:0] pixels_loaded);
localparam IDLE=0,HEADER=1,CHECK=2,PIXELS=3,EMIT=4,ACK=5,FINISH=6,FAIL=15;
reg [3:0] state;reg [7:0] header[0:53];reg [31:0] position,length,offset;
reg rgba,top_down;reg [1:0] channel;reg [7:0] blue,green;
reg [3:0] burst_pixel;reg [15:0] low_pixel;reg [5:0] burst_x;reg [8:0] source_y;
function automatic [15:0] h16(input integer i);h16={header[i+1],header[i]};endfunction
function automatic [31:0] h32(input integer i);h32={header[i+3],header[i+2],header[i+1],header[i]};endfunction
reg [32:0] required_end;
always @(posedge clk) if(reset) required_end<=0;else required_end<={1'b0,h32(10)}+(h16(28)==24?33'd921600:33'd1228800);
wire [15:0] color={byte_data[7:3],green[7:2],blue[7:3]};
wire [8:0] target_y=top_down?source_y:9'd479-source_y;
wire [17:0] target_addr=({9'd0,target_y}<<8)+({9'd0,target_y}<<6)+{9'd0,burst_x,3'b000};
assign byte_ready=(state==HEADER||state==PIXELS)&&!start;
assign load_valid=state==EMIT;assign status={4'd0,state};
always @(posedge clk) begin
 if(reset||start) begin
  state<=start?HEADER:IDLE;position<=0;length<=file_bytes;offset<=0;rgba<=0;top_down<=0;channel<=0;blue<=0;green<=0;
  burst_pixel<=0;low_pixel<=0;burst_x<=0;source_y<=0;load_addr<=0;load_data<=0;load_last<=0;done<=0;error<=0;pixels_loaded<=0;
  if(start&&file_bytes<54) begin error<=10;state<=FAIL;end
 end else if(stream_error!=0&&state!=IDLE&&state!=FINISH) begin error<=stream_error;state<=FAIL;end
 else case(state)
  IDLE,FINISH,FAIL:begin end
  HEADER:if(byte_valid) begin
   header[position[5:0]]<=byte_data;position<=position+1'b1;
   if(position==53) state<=CHECK;
  end
  CHECK:if(h16(0)!=16'h4d42||h32(14)<40||h16(26)!=1||h32(30)!=0) begin error<=8;state<=FAIL;end
   else if(h32(18)!=640||(h32(22)!=480&&h32(22)!=32'hfffffe20)||(h16(28)!=24&&h16(28)!=32)) begin error<=9;state<=FAIL;end
   else if(h32(10)<54||h32(10)>1048576||{1'b0,length}<required_end) begin error<=10;state<=FAIL;end
   else begin offset<=h32(10);rgba<=h16(28)==32;top_down<=header[25][7];state<=PIXELS;end
  PIXELS:if(byte_valid) begin
   position<=position+1'b1;
   if(position>=length) begin error<=7;state<=FAIL;end
   else if(position>=offset) case(channel)
    0:begin blue<=byte_data;channel<=1;end
    1:begin green<=byte_data;channel<=2;end
    2:begin
     channel<=rgba?3:0;pixels_loaded<=pixels_loaded+1'b1;
     if(!burst_pixel[0]) low_pixel<=color;else load_data[(burst_pixel>>1)*32+:32]<={color,low_pixel};
     if(burst_pixel==15) begin
      burst_pixel<=0;load_addr<=target_addr;load_last<=pixels_loaded==307199;state<=EMIT;
      if(burst_x==39) begin burst_x<=0;source_y<=source_y+1'b1;end else burst_x<=burst_x+1'b1;
     end else burst_pixel<=burst_pixel+1'b1;
    end
    3:channel<=0;
   endcase
  end
  EMIT:if(load_ready) state<=ACK;
  ACK:if(load_ack) begin if(load_last) begin done<=1;state<=FINISH;end else state<=PIXELS;end
  default:begin error<=255;state<=FAIL;end
 endcase
end
endmodule
