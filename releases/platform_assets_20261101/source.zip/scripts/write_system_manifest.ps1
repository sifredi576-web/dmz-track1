param()
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
Push-Location $root
try {
 $sources=@(Get-Content scripts/build_system.tcl | Where-Object {$_ -match '^add_files '} | ForEach-Object {$_ -replace '^add_files ../',''})
 $paths=$sources+@('scripts/build_system.tcl','scripts/build_system.ps1','scripts/project.ps1','scripts/system_console.ps1','scripts/pack_platform.py','scripts/preview_platform.py','scripts/test_platform.ps1','scripts/test_media.ps1','tests/test_platform_pack.py','assets/platform/sound_course.json','assets/platform/exhibit_demo.json','sim/platform/tb_scene_loader.sv','sim/platform/loader_main.cpp','sim/platform/course.hex','sim/platform/exhibit.hex','sim/media/tb_media.sv','sim/media/av_fixture.svh','build_system/dmz_track1_Runs/phy_1/dmz_track1.bit')
 $hashes=[ordered]@{}
 foreach($path in ($paths | Sort-Object -Unique)){$hashes[$path]=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
 $timing=Get-Content build_system/dmz_track1_Runs/phy_1/dmz_track1_pr.timing -Raw
 if($timing -notmatch 'SWNS:\s*([\d.-]+)ns'){throw 'Missing setup timing'};$setup=[double]$Matches[1]
 if($timing -notmatch 'HWNS:\s*([\d.-]+)ns'){throw 'Missing hold timing'};$hold=[double]$Matches[1]
 if($setup -lt 0 -or $hold -lt 0){throw 'Timing not passed'}
 [ordered]@{
  generated=(Get-Date).ToString('o');hardware='DMZ_EG4S20 / EG4S20BG256';top='dmz_track1_top';project='build_system/dmz_track1.al'
  stage='platform asset/config preparation and boot validation; UI/action engine not active'
  configuration='bitstream generated; this revision not downloaded or flashed'
  source_and_bitstream_sha256=$hashes;setup_slack_ns=$setup;hold_slack_ns=$hold
  current_software_evidence=@('docs/platform_pack_tests.txt','docs/platform_loader_sim_result.txt','docs/media_sim_result.txt','docs/media_paired_result.txt','docs/media_platform_result.txt','docs/media_platform_invalid_result.txt','docs/platform_asset_validation.json')
  historical_hardware_evidence=@('docs/p7_validation.json','docs/paired_board_validation_20261101.json')
  historical_evidence_scope='Previous bitstreams only. New BRAM stream and configuration bootstrap require hardware validation.'
  pending=@('runtime semantic validation and active configuration tables','name-based resource resolution','SDRAM UI sprites and focus/action engine','single-shot audio completion and course scoring','notification context restoration','hardware validation and Flash cold boot')
 } | ConvertTo-Json -Depth 7 | Set-Content docs/system_manifest.json -Encoding utf8
 Write-Output 'Wrote current system manifest with separate historical hardware evidence'
}finally{Pop-Location}
