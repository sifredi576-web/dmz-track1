# 后续 AI 接手说明

**最新澄清：电脑可仅供电，开发测试允许电脑发命令，最终验收转为板载按键。无需停止现有串口测试；读取、解析和音画处理仍全部在FPGA中完成。此前“断开电脑”指无电脑数据/控制依赖。用户已再次换入合规DEMO.WAV，最新测试见docs/av_corrected_validation.json。**

**最高优先级目标（2026-10-28用户确认）：先读 [固定项目目标](docs/PROJECT_GOALS_LOCKED.md)。最终脱离电脑独立启动，测试/演示素材由板卡与TF卡提供，文件扫描、格式诊断、选择和播放控制均在板端完成。UART仅为开发辅助。下一步优先板载控制、文件菜单/重扫、OSD与TF文件头诊断；不得将复制到电脑解析/转码作为必要流程。五项扩展及非易失启动仍须交付。下文较早的“下一步先字幕”按此顺序修正。**


更新：2026-10-28。当前已完成共享FAT文件服务与TF卡WAV音画播放，下一阶段是字幕与参数OSD。先读本文件，再读 `docs/AV_INTEGRATION_STATUS.md` 和 `docs/PROJECT_PROGRESS.md`。

## 用户最新要求

- 仅处理技术实现，不讨论参赛资格。硬件是大拇指DMZ_EG4S20 / EG4S20BG256，不是推荐HX4S20C。
- 直接推进最终功能；不补与目标无关的一般基础检查，不重复未受改动影响的测试，不每阶段做固定30分钟长测。
- **2026-10-28用户已放入WAV，并明确无需保持默认静音。当前默认图片轮播 + WAV有声播放，音量8/8。** 此要求取代此前静音偏好，结束时不要擅自静音。
- 所有运行时扫描、解析、调度和输出在FPGA内完成；PC只用于构建、下载和控制验证。HDMI协议核为MIT复用，见THIRD_PARTY，不能称全部原创。
- 仅SRAM下载，未写Flash；不要丢弃现有工作区修改，不要reset/clean。

## 当前结果与证据

- 主工程 `build_system/dmz_track1.al`，顶层 `rtl/system/dmz_track1_top.sv`。
- FAT16/FAT32根目录最多32张BMP索引，上一张/下一张、自动轮播与暂停已完成。实卡4张图，完整帧后台写完后消隐提交，切图期间旧图继续显示。
- 共享挂载/目录服务，图片和音频两套复用文件流上下文，单个SD主机和音频低水位优先仲裁已完成；不再用耦合的旧BMP加载器作主工程入口。
- 第一张WAV支持PCM 48kHz/16位/双声道，接入4096对异步PCM FIFO、HDMI、循环、音量和暂停。实际文件1536044字节（DEMO.WAV，8秒）。
- 联动验证记录：WAV已循环32次，音频/画面欠载、SD/WAV/SDRAM错误全0；切图时采样持续增长；H暂停后播放位置保持，A恢复；音量7/8→8/8通过。结束复核仍在继续播放，详见 `docs/av_final_status.json`。
- **用户确认：声音连续，切图画面正常。** `docs/av_validation_summary.json`和`docs/av_board_test_log.txt`是本轮结论。
- 最终时序：建立+1.504ns、保持+0.004ns，STA覆盖99.99%，含SDRAM硬宏；12041 LUT、6350寄存器、32 BRAM9K、10 DSP、1 PLL。后续新增功能须重查时序，尤其保持裕量较小。
- 旧v2的30分钟记录、旧v3图库记录仅是历史，不当作当前v4位流长测。当前只做新功能相关验证。

## 路径与工具

工作区：`D:/QQdownload/HX4S20_Contest_202606.zip/HX4S20_Contest_202606/dmz_track1`。

- TD：`D:/ANLU/bin/td_commands_prompt.exe`，6.2.168116。
- Verilator/Make/g++：`C:/msys64/mingw64/bin`，Verilator 5.036。
- Python：`C:/Users/fushenghe/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe`；文件读写指定UTF-8。
- CH340近期COM9，之前曾COM3/COM8。工具自动找唯一CH340，必要时用-Port指定；不要把近期端口当永久配置。
- TD有时TCL错误也返回0；构建脚本检查新位流、日志和时序，下载脚本检查器件校验与program完成。

```powershell
./scripts/project.ps1 -Action Build
./scripts/project.ps1 -Action Download
./scripts/project.ps1 -Action Status
./scripts/project.ps1 -Action Next
./scripts/project.ps1 -Action Previous
./scripts/project.ps1 -Action Pause
./scripts/project.ps1 -Action Auto
./scripts/project.ps1 -Action AudioPlay
./scripts/project.ps1 -Action AudioPause
./scripts/project.ps1 -Action AudioResume
./scripts/project.ps1 -Action VolumeDown
./scripts/project.ps1 -Action VolumeUp
./scripts/project.ps1 -Action Mute
./scripts/project.ps1 -Action Tone
```

N/P手动切图并停自动，背景WAV继续；H/A联动暂停/恢复；K/L仅音频暂停/恢复；W选WAV并发声；T选测试音并发声；M静音但时间继续；+/-为0..8线性音量。R重载所有媒体，从文件开头再播。Tone模式保留WAV FIFO位置，切回W继续。参数OSD尚未显示这些状态。

## 关键源码

| 文件/目录 | 作用 |
|---|---|
| rtl/media/dmz_fat_catalog.sv | 挂载、BMP索引、首个WAV与共享卷几何 |
| rtl/media/dmz_fat_stream.sv | 图片/音频复用的独立文件上下文、簇链/扇区缓存/反压/取消 |
| rtl/media/dmz_sd_arbiter.sv | 音频低水位优先，整扇区含CRC不打断 |
| rtl/media/dmz_bmp_decoder.sv, dmz_image_player.sv | 流式BMP到RGB565突发 |
| rtl/media/dmz_wav_decoder.sv, dmz_wav_player.sv | RIFF/PCM、循环、错误锁存 |
| rtl/media/dmz_media_storage.sv | 共享文件服务的板上集成入口 |
| rtl/system/dmz_track1_top.sv | 总集成、两类FIFO、HDMI采样、音量、诊断 |
| rtl/system/dmz_media_control.sv | 源、音量、暂停、命令回报；主工程显式DEFAULT_MODE=1/DEFAULT_WAV=1 |
| rtl/p2 | SDRAM控制、自检、FIFO、诊断发送 |
| rtl/p3/dmz_image_framebuffer.sv | 读优先仲裁、双缓冲与消隐提交 |

SDRAM 8MiB，32位字地址/256bit突发，RGB565帧字节基址0和0x100000。**实板READ_WAIT=1，理想引脚仿真=2**。50MHz内存、25MHz像素、125MHz串行；底板无FPGA DDC/HPD，固定640×480约59.524Hz。Audio FIFO AW=12，低于2048优先读，预填512对后开始消费。没有额外音频处理器。

## 本轮验证入口

- `scripts/test_media.ps1`：并发SD/FAT/BMP/WAV、碎片链、3帧921600像素、逐对PCM与循环、反压；FAT32、FAT16+MBR、32位负高度BMP；错误/截断/无WAV时图片继续。
- `scripts/test_status_uart.ps1`：64/96字节诊断及快照一致性。
- `scripts/test_system_control.ps1`：UART/CDC、源与音量、独立/联动暂停、注册重载。
- `scripts/test_av_board.ps1`：实卡音画联动检查，结束后保持有声轮播。
- 不要重复以上通过项目，除非改动影响相应路径。旧P0～P3、旧gallery和protocol测试保留作针对性回归，不必默认全跑。
- Verilator默认$abort在Windows可能弹CRT窗口，新增测试使用自定义C++main关闭fatalOnError并用退出码报失败。PowerShell不要对标量字符串使用数组展开传测试参数，会拆成单字符；使用明确参数或真正的字符串数组。

## 状态协议及已知边界

T1ST **v4为96字节**，24个小端32位字；第23字XOR。0～14沿用v3；15音频欠载、16播放PCM对、17解码PCM对、18解码循环数、19打包FIFO/WAV状态/错误/发现标志、20音频读数、21WAV文件长、22音量/暂停/源/启动标志。完整位定义见AV状态文档。脚本兼容v2/v3/v4；不要用旧64字节脚本读v4。

目前仅第一张根目录WAV，不支持音轨列表、压缩/浮点/单声道/其他采样率，格式错停止该音轨且图片继续。图像仍是640×480未压缩24/32位BMP，不含缩放或转场。H暂停不会取消已开始的图片加载。还没有字幕、亮度/对比度、OSD、PCM图形、应急模式和完整板载按键菜单。

本轮构建曾遇到复位恢复路径和96字节动态选择器路由问题，分别通过寄存restart和诊断快照顺序移位解决；最终时序通过后才下载。保持这些改动，不要靠放宽时序约束隐藏问题。

## 接续任务

1. **下一步：字幕/参数OSD（E1/E4）**。先固定标题/运行时间、滚动文字、音量及播放状态；再亮度/对比度。保持RGB、坐标和HDMI数据有效延迟一致。
2. 图片擦除/滑动转场、等比最近邻缩放（E2/E3）。双图淡入淡出/双线性先评估带宽及资源。
3. 从实际输出PCM做波形、电平、峰值（E5），再考虑FFT；加入应急图文/提示音模式。
4. 增加板载按键/开关控制及完整场景收尾验收。音轨配对/列表与更精细调度可在基本展示稳定后完善。

回退图库：`& D:/ANLU/bin/td_commands_prompt.exe scripts/restore_gallery.tcl`，位流及源码zip在 `releases/gallery_20261027`。更早基线在 `releases/baseline_20261027`。当前AV版归档到 `releases/av_20261028`；最新源/位流哈希见 `docs/system_manifest.json`。未创建PR、未推送、未写Flash。

## 新音频复测（2026-10-28）
用户替换TF卡中的DEMO音频后再次测试。串口起初无状态，重新SRAM下载当前已验证位流后恢复。识别到新WAV 1764078字节，但fmt校验错误3，decoded/played均0，尚未播放。图片4张、手动切换与自动恢复正常，SD/图片/显示欠载错误0。尚不能确定具体格式字段，已向用户询问电脑原文件路径，以便检查并在需要时生成兼容副本；不要把文件大小推测当成采样率证据。当前保留自动轮播/WAV源/音量8、未静音，但格式错误导致输出静音。证据docs/av_replacement_validation.json。此前原测试音频的成功证据保持不变。

## 合规替换音频复测完成（2026-10-28）
用户重新放入1920044字节DEMO.WAV，R重载后正常解码。4张图、手动切图与恢复自动轮播通过；记录末尾WAV解码循环7次，音频/画面欠载、SD/WAV错误均0。用户确认：“新音频正常，切图无明显断音或花屏”。当前保持有声自动轮播、音量8/8。证据：docs/av_corrected_validation.json及其中列出的实板记录。此前1764078字节文件格式失败仅为历史，当前音频故障已解决；无需再要求用户提供电脑文件路径或重复相同播放测试。下一步按固定目标推进板端交互与OSD等未完成功能；电脑可仅供电，开发阶段允许串口控制。
`n板载控制资料已核对，见docs/DMZ_BOARD_CONTROLS.md（照片位置、手册第7页矩阵行列引脚、SW方向）；矩阵扫描尚未实现，接入前核对IO冲突及行列驱动，不能直接套推荐板卡引脚。

## 板载按键阶段（2026-10-28）
已新增dmz_matrix_keys与dmz_board_commands并接入主工程；KEY0下一张、KEY1上一张、KEY2联动暂停/恢复、KEY3静音切换、KEY4/5音量减/加、KEY6恢复轮播、KEY7整链路重扫、KEY8/9音频暂停/恢复、KEY10选WAV；其余保留。位置和电气细节见docs/DMZ_BOARD_CONTROLS.md。列上拉/逐行拉低，其余行高阻；8帧消抖、单次按下、全释放重臂、多键锁定，扫描器不随媒体R重载复位。UART优先且碰撞按键排队，协议仍为T1ST v4，通过command_count/last_command观察两类命令。
仿真scripts/test_board_keys.ps1覆盖16键、弹跳、长按、多键/鬼键、复位持键和UART碰撞，通过。新构建时序setup +1.422ns、hold +0.076ns，12311 LUT、6435寄存器、32 BRAM9K、10 DSP、1 PLL。已SRAM下载；docs/keys_initial_status.json确认4图+1920044字节WAV正常，错误/欠载0。实际按键用户操作待确认，不能称所有实体按键已验收。后续仍需文件菜单、OSD、五项扩展、应急与非易失启动。

板载按键实测更新：用户确认“切图、暂停和恢复均正常”；docs/keys_physical_observation.json捕获物理KEY0产生N、KEY2产生H/A（亦观察到P命令），各暂停段内played_pairs保持、恢复后继续，结束auto=true、paused=false、未静音，错误/欠载0。仅KEY0/KEY2为本轮用户明确确认的实体操作，其余键不冒称已实测。证据docs/keys_validation_summary.json，回退归档releases/keys_20261028，后续优先文件菜单和OSD；无需重复刚通过的播放测试。
