// Simulation-only FAT32 disk backed by the real package. Not linked into FPGA RTL.
#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>
namespace {
struct File { std::string name; std::vector<uint8_t> data; uint32_t first; };
std::vector<File> files;
std::map<uint32_t,uint32_t> fat;
std::map<uint32_t,std::pair<unsigned,unsigned>> blocks;
std::vector<uint8_t> directory;
std::vector<unsigned> waves;
bool initialized=false;
void put(std::vector<uint8_t>& data,unsigned at,uint32_t value,unsigned bytes) {
 for(unsigned j=0;j<bytes;j++)data[at+j]=uint8_t(value>>(8*j));
}
void init() {
 if(initialized)return;
 initialized=true;
 const char* selected=std::getenv("DMZ_TEST_PACKAGE");
 std::filesystem::path path=selected?selected:"../../assets/platform/tf_course_v2";
 std::vector<std::filesystem::path> paths;
 for(const auto& e:std::filesystem::directory_iterator(path)) {
  auto ext=e.path().extension().string();
  if(ext==".BMP"||ext==".WAV"||e.path().filename()=="SCENE.BIN")paths.push_back(e.path());
 }
 std::sort(paths.rbegin(),paths.rend());
 uint32_t cluster=4;fat[2]=3;fat[3]=0x0fffffff;
 directory.resize(1024,0);
 for(const auto& p:paths) {
  std::ifstream stream(p,std::ios::binary);
  File file{p.filename().string(),std::vector<uint8_t>(std::istreambuf_iterator<char>(stream),{}),cluster};
  unsigned slot=unsigned(files.size()),offset=0;
  for(;offset<file.data.size();offset+=512,cluster+=2) {
   blocks[cluster]={slot,offset};
   fat[cluster]=offset+512<file.data.size()?cluster+2:0x0fffffff;
  }
  unsigned at=slot*32;
  std::fill(directory.begin()+at,directory.begin()+at+11,' ');
  const auto stem=p.stem().string(),ext=p.extension().string().substr(1);
  std::copy(stem.begin(),stem.end(),directory.begin()+at);
  std::copy(ext.begin(),ext.end(),directory.begin()+at+8);
  directory[at+11]=0x20;
  put(directory,at+20,file.first>>16,2);put(directory,at+26,file.first&65535,2);put(directory,at+28,unsigned(file.data.size()),4);
  if(ext=="WAV")waves.push_back(slot);
  files.push_back(std::move(file));
 }
}
}
extern "C" unsigned int dmz_disk(unsigned int lba,unsigned int index) {
 init();
 if(lba==0) {
  std::vector<uint8_t> boot(512,0);
  put(boot,11,512,2);boot[13]=1;put(boot,14,1,2);boot[16]=1;
  put(boot,32,262144,4);put(boot,36,1024,4);put(boot,44,2,4);put(boot,510,0xaa55,2);
  return boot.at(index);
 }
 if(lba<=1024) {
  uint32_t entry=(lba-1)*128+index/4;
  uint32_t value=entry<2?0x0fffffff:(fat.count(entry)?fat.at(entry):0);
  return uint8_t(value>>(8*(index%4)));
 }
 uint32_t cluster=lba-1025+2;
 if(cluster==2||cluster==3)return directory.at((cluster-2)*512+index);
 auto found=blocks.find(cluster);
 if(found==blocks.end())throw std::runtime_error("unexpected unallocated sector");
 auto [slot,offset]=found->second;
 return offset+index<files[slot].data.size()?files[slot].data[offset+index]:0;
}
extern "C" unsigned int dmz_expected_pcm(unsigned int wave,unsigned int sample) {
 init();const auto& data=files.at(waves.at(wave)).data;
 unsigned at=12;
 while(at+8<=data.size()) {
  uint32_t size=uint32_t(data[at+4])|(uint32_t(data[at+5])<<8)|(uint32_t(data[at+6])<<16)|(uint32_t(data[at+7])<<24);
  if(std::string(reinterpret_cast<const char*>(&data[at]),4)=="data") {
   unsigned pos=at+8+(sample%(size/4))*4;
   return uint32_t(data[pos])|(uint32_t(data[pos+1])<<8)|(uint32_t(data[pos+2])<<16)|(uint32_t(data[pos+3])<<24);
  }
  at+=8+size+(size&1);
 }
 throw std::runtime_error("missing WAV PCM data");
}
