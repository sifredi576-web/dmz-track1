param([string]$TdRoot='D:/ANLU',[switch]$VerifyOnly)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
Push-Location $root
try {
 $start=Get-Date
 New-Item -ItemType Directory -Force build_system | Out-Null
 if(!$VerifyOnly){
 Push-Location build_system
 try {& "$TdRoot/bin/td_commands_prompt.exe" '../scripts/build_system.tcl' *> ../docs/system_build_log.txt} finally {Pop-Location}
 }
 $bit=Get-Item build_system/dmz_track1_Runs/phy_1/dmz_track1.bit
 if(!$bit.Length -or (!$VerifyOnly -and $bit.LastWriteTime -lt $start)){throw 'No fresh unified system bitstream'}
 $logs=(Get-Content docs/system_build_log.txt -Raw)+(Get-Content build_system/dmz_track1_Runs/syn_1/run.log -Raw)+(Get-Content build_system/dmz_track1_Runs/phy_1/run.log -Raw)
 if($logs -match 'ERROR:'){throw 'Build error'}
 $badNets=$logs -split "`n" | Where-Object {
  ($_ -match 'undeclared symbol|HDL-5314[^\r\n]*does not have a driver') -and
  ($_ -notmatch "undeclared symbol 'open'.*dmz_p2_pll\.v") -and
  # TD reports initialized ROM arrays and the unused serial BIST branch before
  # constant propagation. These exact reviewed objects are not runtime inputs.
  ($_ -notmatch "net 'read_data\[255\]'.*dmz_sdram_bist\.sv") -and
  ($_ -notmatch "net '(text_rom|font_rom)'.*dmz_osd\.sv")
 }
 if($badNets){throw ('Undeclared or undriven HDL net: '+($badNets -join '; '))}
 # Known hard-macro relocation and single-destination internal clock pad warnings.
 $critical=$logs -split "`n" | Where-Object {$_ -match 'CRITICAL-WARNING' -and $_ -notmatch 'PHY-7002|PHY-5079'}
 if($critical){throw ('Unreviewed critical warning: '+($critical -join '; '))}
 $r=Get-Content build_system/dmz_track1_Runs/phy_1/dmz_track1_pr.timing -Raw
 if($r -match '(?:S|H)WNS:\s*-' -or $r -notmatch 'Timing details for EG_PHY_SDRAM_2M_32' -or $r -notmatch '125.000'){throw 'Timing or SDRAM coverage failed'}
 Write-Output 'PASS: unified system bitstream, reviewed synthesis nets and routed timing including SDRAM hard macro'
}finally{Pop-Location}
