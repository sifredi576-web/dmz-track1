﻿param()
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
Push-Location $root
try {
 $sources=@(Get-Content scripts/build_system.tcl | Where-Object {$_ -match '^add_files '} | ForEach-Object {$_ -replace '^add_files ../',''})
 $ui_paths=@('scripts/test_ui.ps1','scripts/test_osd_menu.ps1','scripts/test_system_control.ps1','scripts/test_display.ps1','sim/platform/tb_ui_keys.sv','sim/platform/tb_ui_controller.sv','sim/platform/tb_fifo_recode.sv','sim/platform/tb_ui_keys_main.cpp','sim/platform/tb_ui_controller_main.cpp','sim/platform/tb_fifo_recode_main.cpp')
 $runtime_paths=@(Get-ChildItem rtl/platform,sim/platform -Recurse -File | ForEach-Object {$_.FullName.Substring($root.Length+1).Replace('\','/')})+@('scripts/test_runtime.ps1','scripts/generate_osd_text_rom.py','assets/osd_text_lines.json','tests/test_console_parser.ps1','assets/platform/tf_course_v2/SCENE.BIN','assets/platform/tf_notice_v2/SCENE.BIN')
 $paths=$sources+$ui_paths+$runtime_paths+@('scripts/build_system.tcl','scripts/build_system.ps1','scripts/project.ps1','scripts/system_console.ps1','scripts/pack_platform.py','scripts/preview_platform.py','scripts/test_platform.ps1','scripts/test_media.ps1','tests/test_platform_pack.py','assets/platform/sound_course.json','assets/platform/exhibit_demo.json','sim/platform/tb_scene_loader.sv','sim/platform/loader_main.cpp','sim/platform/course.hex','sim/platform/exhibit.hex','sim/media/tb_media.sv','sim/media/av_fixture.svh','build_system/dmz_track1_Runs/phy_1/dmz_track1.bit')
 $hashes=[ordered]@{}
 foreach($path in ($paths | Sort-Object -Unique)){$hashes[$path]=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
 $timing=Get-Content build_system/dmz_track1_Runs/phy_1/dmz_track1_pr.timing -Raw
 if($timing -notmatch 'SWNS:\s*([\d.-]+)ns'){throw 'Missing setup timing'};$setup=[double]$Matches[1]
 if($timing -notmatch 'HWNS:\s*([\d.-]+)ns'){throw 'Missing hold timing'};$hold=[double]$Matches[1]
 if($setup -lt 0 -or $hold -lt 0){throw 'Timing not passed'}
 [ordered]@{
  generated=(Get-Date).ToString('o');hardware='DMZ_EG4S20 / EG4S20BG256';top='dmz_track1_top';project='build_system/dmz_track1.al'
  stage='interactive platform v2: configured Chinese course, quiz, notifications and media integrated'
  configuration='bitstream generated; this revision not downloaded or flashed'
  source_and_bitstream_sha256=$hashes;setup_slack_ns=$setup;hold_slack_ns=$hold
  current_software_evidence=@('docs/platform_runtime_validation.json','docs/scene_runtime_result.txt','docs/scene_runtime_notice_result.txt','docs/platform_media_result.txt','docs/platform_media_notice_result.txt','docs/platform_media_timed_result.txt','docs/page_compositor_result.txt','docs/audio_completion_result.txt','docs/scene_runtime_badmeta_result.txt','docs/scene_runtime_badwidget_result.txt','docs/scene_runtime_badcrc_result.txt','docs/platform_pack_tests.txt','docs/platform_loader_sim_result.txt','docs/media_sim_result.txt','docs/media_paired_result.txt','docs/media_platform_result.txt','docs/media_platform_invalid_result.txt','docs/ui_keys_validation.json','docs/ui_keys_result.txt','docs/ui_controller_result.txt','docs/fifo_recode_result.txt','docs/osd_menu_sim_result.txt','docs/system_control_sim_result.txt','docs/display_sim_result.txt')
  historical_hardware_evidence=@('docs/p7_validation.json','docs/paired_board_validation_20261101.json')
  historical_evidence_scope='Previous bitstreams only. This v2 course, Chinese overlays, notification restore, production diagnostics and 2048-pair FIFO require hardware validation.'
  pending=@('hardware validation of current course and second scene','measured AV boundary and TF extreme read latency','Flash programming and cold boot','final demonstration video and documentation')
 } | ConvertTo-Json -Depth 7 | Set-Content docs/system_manifest.json -Encoding utf8
 Write-Output 'Wrote current system manifest with separate historical hardware evidence'
}finally{Pop-Location}
